stdlib.background.video(content, "fireworks.webm", "#25190d");

await stdlib.audio.load(content.files["nothin_on_you.ogg"]);
stdlib.audio.visualiser.enable("110,157,137");
