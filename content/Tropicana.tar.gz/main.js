stdlib.background.video(content, "wolf_children.webm", "#181a1a");

await stdlib.audio.load(content.files["tropicana.ogg"]);
stdlib.audio.visualiser.enable("201,211,218");
