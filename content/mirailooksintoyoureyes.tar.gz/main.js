stdlib.background.video(content, "mirai.webm", "#0f0e0f");

await stdlib.audio.load(content.files["eyes.ogg"]);
stdlib.audio.visualiser.enable("238,168,136");
