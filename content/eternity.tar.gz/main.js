stdlib.background.video(content, "dragon_maid.webm", "#f5d5af");

await stdlib.audio.load(content.files["eternity.ogg"]);
stdlib.audio.visualiser.enable("71,158,126");
