stdlib.background.video(content, "tsugumi.webm", "#222e33");

await stdlib.audio.load(content.files["propane_nightmares.ogg"]);
