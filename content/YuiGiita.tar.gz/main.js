stdlib.background.video(content, "yui.webm", "#e7e4d0");

await stdlib.audio.load( content.files["my_love_is_a_stapler.ogg"] );
stdlib.audio.visualiser.enable("54, 61, 76");
