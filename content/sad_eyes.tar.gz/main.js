stdlib.background.video(content, "asako.webm", "#f07674");

await stdlib.audio.load(content.files["see_you_again.ogg"]);
stdlib.audio.visualiser.enable("255,255,255");
